global.domain = "www.smxsdezx.cn";

global.salt = "smxsdezx-website";

global.salt2 = "smxsdezx"; 
const errMsgList = {
	"jwt expired": "登录超时，请重新登录",
	"invalid token": "授权失败，请重新登录"
}